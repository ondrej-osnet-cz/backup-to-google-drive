import { Injectable } from '@nestjs/common';
import * as fs from 'fs';

@Injectable()
export class SettingsService {

    private sourceFolder: string;

    private googleRefreshToken: string;

    constructor(pathToConfig: string) {
        const configString = fs.readFileSync(pathToConfig, 'utf8');
        const configData = JSON.parse(configString);
        this.sourceFolder = process.env.sourceFolder || configData.source_folder;
        if (process.env.googleRefreshTokenFile) {
            this.googleRefreshToken = fs.readFileSync(process.env.googleRefreshTokenFile, 'utf8');
        } else {
            this.googleRefreshToken = configData.google_refresh_token;
        }
    }

    public getSourceFolder() {
        return this.sourceFolder;
    }

    public getTargetFolder() {
        return '/home/node/data';
    }

    public getGoogleRefreshToken() {
        return this.googleRefreshToken;        
    }
}
